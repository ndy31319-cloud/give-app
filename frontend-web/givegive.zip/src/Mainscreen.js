import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function MainScreen() {
  const navigate = useNavigate();

  const [selectedCategory, setSelectedCategory] = useState('digital');

  
  const allItems = [
    { id: 1, category: 'digital', title: '블루투스 헤드셋', location: '서초동', time: '1시간 전', img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400' },
    { id: 2, category: 'digital', title: '사무용 키보드', location: '반포동', time: '3시간 전', img: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=400' },
    { id: 3, category: 'fashion', title: '여름용 반팔 티셔츠', location: '양재동', time: '10분 전', img: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400' },
    { id: 4, category: 'fashion', title: '아동용 운동화', location: '서초동', time: '2시간 전', img: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400' },
    { id: 5, category: 'furniture', title: '우드 미니 협탁', location: '방배동', time: '5시간 전', img: 'https://images.unsplash.com/photo-1544457070-4cd773b4d71e?w=400' },
    { id: 6, category: 'furniture', title: '초록색 1인용 소파', location: '양재동', time: '어제', img: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400' },
    { id: 7, category: 'book', title: '자기계발 베스트셀러', location: '서초동', time: '30분 전', img: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400' },
    { id: 8, category: 'book', title: '어린이 동화 전집', location: '반포동', time: '4시간 전', img: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400' },
  ];

 
  const filteredItems = selectedCategory === 'all' 
    ? allItems 
    : allItems.filter(item => item.category === selectedCategory);

  return (
    <div className="p-8 bg-[#F8F9FA] min-h-screen" style={{ fontFamily: "'Noto Sans KR', sans-serif", letterSpacing: "-0.05em" }}>
      
      {/* 상단 헤더 영역 */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-[32px] font-bold text-[#0047FF] mb-1">나눔 플랫폼 키오스크</h1>
          <p className="text-[18px] text-gray-500">안녕하세요, <span className="font-bold text-gray-800">1111</span>님</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => navigate('/wanted')} className="bg-[#E9F0FF] text-[#0047FF] px-6 py-3 rounded-xl flex items-center gap-2 text-[16px] font-bold shadow-sm hover:bg-[#D6E4FF] active:scale-95 transition-all">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            나눔 요청
          </button>
          <button onClick={() => navigate('/mypage-buyer')} className="bg-white border-2 border-gray-100 text-[#333] px-6 py-3 rounded-xl flex items-center gap-2 text-[16px] font-bold shadow-sm active:scale-95 transition-all hover:bg-gray-50">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            마이페이지
          </button>
          <button onClick={() => navigate('/')} className="bg-[#6C757D] text-white px-6 py-3 rounded-xl flex items-center gap-2 text-[16px] font-medium shadow-sm hover:bg-[#5A6268] active:scale-95 transition-all">
            로그아웃
          </button>
        </div>
      </div>

      {/* 카테고리 선택 영역 */}
      <div className="mb-12">
        <h2 className="text-[24px] font-bold text-[#333] mb-6">카테고리</h2>
        <div className="flex gap-4 overflow-x-auto pb-4">
          {[
            { id: 'all', name: '전체', icon: <rect x="3" y="3" width="7" height="7"/> },
            { id: 'digital', name: '디지털/가전', icon: <rect x="5" y="2" width="14" height="20" rx="2"/> },
            { id: 'fashion', name: '패션/의류', icon: <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/> },
            { id: 'furniture', name: '가구/인테리어', icon: <path d="M3 7h18"/> },
            { id: 'book', name: '도서', icon: <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/> },
          ].map((cat) => (
            <button 
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`min-w-[150px] h-[160px] rounded-[24px] flex flex-col items-center justify-center gap-4 shadow-sm transition-all border-2 
                ${selectedCategory === cat.id ? 'bg-[#0047FF] border-[#0047FF] text-white' : 'bg-white border-gray-100 text-gray-600'}`}
            >
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {cat.icon}
                {cat.id === 'all' && <><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></>}
                {cat.id === 'digital' && <path d="M12 18h.01"/>}
                {cat.id === 'fashion' && <><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></>}
                {cat.id === 'furniture' && <><path d="M19 7v10"/><path d="M5 7v10"/></>}
                {cat.id === 'book' && <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5V4.5z"/>}
              </svg>
              <span className={`text-[18px] font-bold ${selectedCategory === cat.id ? 'text-white' : 'text-gray-600'}`}>
                {cat.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 물품 리스트 영역 */}
      <div>
        <h2 className="text-[24px] font-bold text-[#333] mb-6">나눔 물품</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {filteredItems.map(item => (
            <div key={item.id} className="bg-white rounded-[28px] overflow-hidden shadow-sm border border-gray-100 active:scale-[0.98] transition-all cursor-pointer">
              <div className="h-48 bg-gray-100">
                <img src={item.img} alt={item.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-5">
                <h3 className="text-[20px] font-bold text-[#333]">{item.title}</h3>
                <p className="text-gray-400">{item.location} · {item.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default MainScreen;