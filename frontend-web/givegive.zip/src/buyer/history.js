import React from 'react';
import { useNavigate } from 'react-router-dom';

function History() {
  const navigate = useNavigate();

  // 이용 내역 데이터 (나중에 DB에서 가져올 데이터)
  const historyData = [
    {
      id: 1,
      status: '나눔 승인 대기',
      statusColor: 'bg-[#E9F0FF] text-[#0047FF]',
      title: '빈티지 필름 카메라',
      donor: '김나눔',
      date: '2026.02.18',
      img: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=200',
      isWaiting: true,
    },
    {
      id: 2,
      status: '나눔 수령 완료',
      statusColor: 'bg-gray-100 text-gray-500',
      title: '고성능 노트북',
      donor: '이기부',
      date: '2026.01.20',
      img: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=200',
      isWaiting: false,
    }
  ];

  return (
    <div className="p-8 bg-[#F8F9FA] min-h-screen" style={{ fontFamily: "'Noto Sans KR', sans-serif", letterSpacing: "-0.05em" }}>
      
      {/* 상단 헤더 */}
      <div className="flex items-center gap-4 mb-10">
        <button 
          onClick={() => navigate('/mypage-buyer')} 
          className="hover:bg-gray-100 p-2 rounded-full transition-all"
        >
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#333" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <h1 className="text-[36px] font-bold text-[#333]">나눔 이용 내역</h1>
      </div>

      {/* 내역 리스트 */}
      <div className="space-y-6">
        {historyData.map((item) => (
          <div 
            key={item.id} 
            className={`bg-white rounded-[32px] p-8 shadow-sm flex justify-between items-center transition-all ${item.isWaiting ? 'border-2 border-[#0047FF]' : 'border border-gray-100 opacity-70'}`}
          >
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 bg-gray-100 rounded-2xl overflow-hidden shrink-0">
                <img src={item.img} alt={item.title} className="w-full h-full object-cover" />
              </div>
              <div>
                <span className={`${item.statusColor} px-3 py-1 rounded-lg text-[14px] font-bold mb-2 inline-block`}>
                  {item.status}
                </span>
                <h3 className="text-[24px] font-bold text-[#333]">{item.title}</h3>
                <p className="text-gray-400">기부자: {item.donor} · {item.date}</p>
              </div>
            </div>

            {}
            {item.isWaiting ? (
              <button 
                onClick={() => alert('신청이 취소되었습니다.')}
                className="bg-[#F1F3F5] text-[#666] px-6 py-4 rounded-2xl font-bold text-[18px] active:scale-95 transition-all"
              >
                신청 취소
              </button>
            ) : (
              <button 
                onClick={() => navigate('/review')} 
                className="bg-[#0047FF] text-white px-6 py-4 rounded-2xl font-bold text-[18px] hover:bg-blue-700 active:scale-95 transition-all"
              >
                후기 작성
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default History;