import React from 'react';
import { useNavigate } from 'react-router-dom';

function WantedList() {
  const navigate = useNavigate();

  // 나눔 요청 데이터 배열 나중에 DB로해야함
  const wantedItems = [
    {
      id: 1,
      status: '급해요!',
      statusColor: 'bg-orange-100 text-orange-600',
      time: '30분 전',
      title: '전공 서적 (컴퓨터 공학)',
      desc: '자료구조나 알고리즘 관련 전공 서적 구합니다. 상태 상관없이 공부용으로 필요해요!',
      user: '익명요청자',
      emoji: '👤',
      isCompleted: false
    },
    {
      id: 2,
      status: '기다려요',
      statusColor: 'bg-green-100 text-green-600',
      time: '2시간 전',
      title: '아이 유모차',
      desc: '둘째가 태어나서 유모차가 하나 더 필요하게 되었습니다. 나눔 주시면 감사히 잘 쓰겠습니다.',
      user: '초보맘',
      emoji: '👶',
      isCompleted: false
    },
    {
      id: 3,
      status: '나눔 완료',
      statusColor: 'bg-gray-100 text-gray-500',
      time: '어제',
      title: '안쓰시는 멀티탭',
      desc: '방 구조를 옮기는데 멀티탭이 부족하네요. 3구 이상이면 좋겠습니다!',
      user: '자취생A',
      emoji: '',
      isCompleted: true
    }
  ];

  return (
    <div className="p-8 bg-[#F8F9FA] min-h-screen" style={{ fontFamily: "'Noto Sans KR', sans-serif", letterSpacing: "-0.05em" }}>
      
      {/* 상단 헤더 */}
      <div className="flex justify-between items-center mb-10">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/buyer-main')} 
            className="hover:bg-gray-100 p-2 rounded-full transition-all"
          >
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#333" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          <h1 className="text-[36px] font-bold text-[#333]">나눔 요청 게시판</h1>
        </div>
        
        <button 
          onClick={() => navigate('/write-wanted')} // 글쓰기 페이지 이동 (추후 생성)
          className="bg-[#0047FF] text-white px-8 py-4 rounded-[20px] flex items-center gap-3 text-[20px] font-bold shadow-lg shadow-blue-100 active:scale-95 transition-all hover:bg-blue-700"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
          물품 요청하기
        </button>
      </div>

      {/* 안내 문구 */}
      <div className="bg-blue-50 p-6 rounded-[24px] mb-10 flex items-center gap-4 border border-blue-100">
        <span className="text-[30px]">💡</span>
        <p className="text-blue-700 text-[18px] font-medium">
          찾으시는 물품이 없나요? 요청 게시판에 남겨주시면 이웃들이 확인 후 나눔을 시작할 수 있어요!
        </p>
      </div>

      {/* 요청 카드 그리드 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {wantedItems.map((item) => (
          <div 
            key={item.id} 
            className={`bg-white p-8 rounded-[32px] shadow-sm border border-gray-100 transition-all active:scale-[0.98] ${item.isCompleted ? 'opacity-80' : ''}`}
          >
            <div className="flex justify-between items-start mb-4">
              <span className={`${item.statusColor} px-4 py-1 rounded-full font-bold text-[14px]`}>
                {item.status}
              </span>
              <span className="text-gray-400 text-[16px]">{item.time}</span>
            </div>
            
            <h3 className="text-[26px] font-bold text-[#333] mb-2">{item.title}</h3>
            <p className="text-gray-500 text-[18px] mb-6 leading-relaxed">{item.desc}</p>
            
            <div className="flex justify-between items-center border-t pt-6">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-[20px]">
                  {item.emoji}
                </div>
                <span className={`font-bold ${item.isCompleted ? 'text-gray-400' : 'text-gray-700'}`}>
                  {item.user}
                </span>
              </div>
              
              {item.isCompleted ? (
                <span className="bg-gray-100 text-gray-400 px-6 py-2 rounded-xl font-bold">매칭 완료</span>
              ) : (
                <button className="text-[#0047FF] font-bold text-[18px] border-2 border-[#0047FF] px-6 py-2 rounded-xl active:bg-blue-50 transition-all">
                  나눔해주기
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default WantedList;